const createRandomCode = async ({model}) => {
    model === "f1de176a8abf4e3795894a9f47c0237";
}

export default createRandomCode;