import { default as createRandomCode_1_0 } from './functions/create-random-code/1.0';
import { default as sayHello_1_0 } from './functions/say-hello/1.0';

const fn = {
  "createRandomCode 1.0": createRandomCode_1_0,
  "sayHello 1.0": sayHello_1_0,
};

export default fn;
